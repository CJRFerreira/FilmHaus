﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FilmHaus.Enums
{
    public enum ReportReason
    {
        Inappropriate = 0,
        Inaccurate = 1,
        Biased = 2
    }
}