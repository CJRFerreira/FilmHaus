﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FilmHaus.Enums
{
    public enum ReportStatus
    {
        Unresolved = 0,
        Accepted = 1,
        Rejected = 2
    }
}