﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FilmHaus.Enums
{
    public enum AwardStatus
    {
        Nominated = 0,
        Won = 1,
        None = 2
    }
}